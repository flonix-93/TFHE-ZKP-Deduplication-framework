import os

def view_and_save_decrypted_file(file_path, new_file_path):
    with open(file_path, 'rb') as file:
        data = file.read()
    
    # Decode the data, replacing errors
    decoded_data = data.decode('utf-8', errors='replace')
    
    # Print the decoded data to the console
    print(decoded_data)
    
    # Save the decoded data to a new file
    with open(new_file_path, 'w', encoding='utf-8') as new_file:
        new_file.write(decoded_data)

if __name__ == "__main__":
    file_path = os.path.join('C:\\research\\new\\tfhe_project\\research\\decrypted_files', 'dec_1MiB.txt_original.bin')
    new_file_path = os.path.join('C:\\research\\new\\tfhe_project\\research\\decrypted_files', 'decrypted_output_original.txt')
    view_and_save_decrypted_file(file_path, new_file_path)
