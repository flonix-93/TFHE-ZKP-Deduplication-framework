from flask import Flask

def create_app():
    app = Flask(__name__, template_folder='templates')
    app.config['UPLOAD_FOLDER'] = 'uploads'
    app.config['ENCRYPTED_FOLDER'] = 'encrypted_files'
    app.config['DECRYPTED_FOLDER'] = 'decrypted_files'
    app.config['DEDUPLICATION_LOG'] = 'deduplication_log.txt'

    with app.app_context():
        from . import routes

    return app
